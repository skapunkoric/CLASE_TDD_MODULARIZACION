
#msg = ""
def cantidad_usuario(msg):
    #cantidad_pedida = input("🔍 Ingrese la cantidad de stock a filtrar: ").strip()
    cantidad_pedida = input(msg).strip()
    if cantidad_pedida.isdigit():
        return int(cantidad_pedida)
    else:
        print("⚠️ Error: Debe ingresar un número entero válido.")
        return None


def determinar_estado_stock(cantidad):
    "funcion pura que recibe un numero y devuelve un string"    
    if cantidad == 0:
        return "❌ [SIN STOCK]"
    elif cantidad <= 3:
        return "⚠️ [STOCK BAJO]"
    else:
        return "✅ [STOCK OK]"

def updatear_productos():
    "cambiar datos de los productos del inventario para actualizar, Devuelve strings vacíos si el usuario da Enter."""
    print("\n--- MODIFICAR PRODUCTO ---")
    print("(Presioná Enter sin escribir nada para mantener el valor actual)")

    id_prod = cantidad_usuario("Ingrese el Id de Producto para su modificacion: ")
    nombre_act = input("Nuevo Nombre del producto: ").strip()
    cantidad_act = cantidad_usuario("Ingrese Nueva cantidad: ")
    estado_stock_act = input("Nuevo Estado de Stock: ").strip()

    return id_prod, nombre_act, cantidad_act, estado_stock_act
